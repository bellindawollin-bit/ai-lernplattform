// Einfaches Formular-Event
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Nachricht gesendet! Vielen Dank.');
});
