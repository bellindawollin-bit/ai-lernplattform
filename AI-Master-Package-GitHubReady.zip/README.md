
# 🚀 AI-Master-Package

[![Live Demo](https://img.shields.io/badge/Live%20Demo-Online-brightgreen?style=for-the-badge)](https://your-github-user.github.io/ai-master-package-docs/)

Ein komplettes Paket für AI-Projekte inkl. **Vorlagen**, **Dokumentation**, **Installationsskripte** und einer **modernen Web-Doku** (One-Page & Multi-Page).

---

## ✅ Features
✔ EXE-Template für Desktop-Apps  
✔ GitHub-Template für Webprojekte  
✔ Umfangreiche Dokumentation (PDFs + Quick Start)  
✔ Hash-Prüfung (MD5 & SHA256)  
✔ Responsive Web-Doku für GitHub Pages  

---

## 🌍 Live Demo
🔗 **[Klicke hier für die Online-Demo](https://your-github-user.github.io/ai-master-package-docs/)**

---

## 📦 Downloads
- [AI-Master-Package.txt](./AI-Master-Package.txt)
- [AI-Master-Package-Final-Plus.zip](./AI-Master-Package-Final-Plus.zip)
- [setup_windows.ps1](./setup_windows.ps1)
- [setup_linux.sh](./setup_linux.sh)
- [Quick-Start.md](./Quick-Start.md)

---

## 🔧 Installation
### Windows (PowerShell)
```powershell
$Base64 = Get-Content -Path ".\\AI-Master-Package.txt" | Select-String -Pattern "^[A-Za-z0-9+/=]+$" | ForEach-Object { $_.ToString() }
[IO.File]::WriteAllBytes("AI-Master-Package.zip", [Convert]::FromBase64String(($Base64 -join '')))
Expand-Archive -Path "AI-Master-Package.zip" -DestinationPath ".\\AI-Master-Package"
```

### Linux/Mac
```bash
grep -E '^[A-Za-z0-9+/=]+$' AI-Master-Package.txt | tr -d '\\n' | base64 --decode > AI-Master-Package.zip
unzip AI-Master-Package.zip -d AI-Master-Package
```

---

## 📂 Projektstruktur
```
AI-Master-Package/
├── EXE-Template/
├── GitHub-Template/
├── docs/
└── README.md
```

---

## ✅ Roadmap
- [x] One-Page Web-Doku
- [x] Multi-Page Web-Doku
- [ ] Logo & Branding
- [ ] Installer (.exe + GUI)

---

## 🖼 Screenshots
*(Bilder kannst du später hier hinzufügen)*

---

### ⭐ Star dieses Repo, wenn es dir gefällt!
